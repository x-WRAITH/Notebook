﻿namespace Notatnik
{
    public class Colors
    {
    }
}